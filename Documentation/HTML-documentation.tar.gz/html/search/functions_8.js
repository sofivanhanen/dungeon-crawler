var searchData=
[
  ['move',['Move',['../classGameObjectControllers_1_1GhostController.html#acb75fb5c011d4a2c7a2189a36cc24fc7',1,'GameObjectControllers.GhostController.Move()'],['../interfaceInterfaces_1_1IEnemyFollowing.html#a62b1c4bc9df4998da252d270ef8f80e7',1,'Interfaces.IEnemyFollowing.Move()']]]
];
